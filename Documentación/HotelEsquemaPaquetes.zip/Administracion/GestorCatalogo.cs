namespace Administracion {
    public class GestorCatalogo {
        public void AgregarHabitacion(Modelos.Habitacion habitacion) { }
    }}