namespace BaseDatos {
    public class Repositorio {
        public void GuardarReserva(Modelos.Reserva reserva) { }
        public void GuardarPago(Modelos.Pago pago) { }
    }}