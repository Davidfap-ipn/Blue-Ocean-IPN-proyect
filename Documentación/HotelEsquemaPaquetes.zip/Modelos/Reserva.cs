namespace Modelos {
    public class Reserva {
        public int Id { get; set; }
        public int IdHabitacion { get; set; }
        public string EmailUsuario { get; set; }
    }}