namespace Modelos {
    public class Usuario {
        public string Nombre { get; set; }
        public string Email { get; set; }
    }}