<?php 

class CtrlCatologo{
	private $recurso = "_view/catalogo";
	private $datos;
	
	  public function renderContent(){
		  include $this->recurso;
		  }
}
