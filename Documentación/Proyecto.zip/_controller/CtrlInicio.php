<?php 

class CtrlInicio{
	private $recurso = "_view/inicio.html";
	private $datos;
	
	  public function renderContent(){
		  include $this->recurso;
		  }
}
