<?php 
require_once "_model/MainModel.php";

class CtrlListaProducto{
	private $recurso = "_view/lista_producto.html";
	private $datos;
	
	  public function __construct(){
		  $model = new MainModel();
		  $this->datos = $model -> getDataRows("producto", ["id_prod", "nombre","precio"]);
	  }
	  public function renderContent(){
		  include $this->recurso;
		  }
}
//los archivos de clase/libreria NO se cierran

