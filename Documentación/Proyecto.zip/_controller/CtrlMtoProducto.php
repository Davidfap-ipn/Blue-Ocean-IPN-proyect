<?php
require_once "_model/MainModel.php";

class CtrlMtoProducto{
	private $recurso = "_view/mto_producto.html";
	private $datos;
	
	
	public function renderContent(){
		include $this->recurso;
	}
	
	public function renderJS() {
		include "js/ctrlmtoproducto.js";
	}
}

//Los archivos de clase/libreria NO se cierran 
