<?php

require_once "class/MySQLAux.php";
class MainModel{
		public function getDataRows($tabla, $campos, $condicion = null, $params = null){
			$mysql = new MySQLAux("localhost", "papeleria", "root", "12345678");
			$datos = $mysql -> selectRows($tabla, $campos, $condicion, $params);
			
			return $datos;
		}
}
