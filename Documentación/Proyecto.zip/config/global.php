<?php
   define("SITE_PATH", "http://localhost/marsan/");
   define("RUTA_DEFAULT", "producto");
