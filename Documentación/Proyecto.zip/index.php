<?php
ini_set("display_errors", E_ALL); // Muestra todos los errores para facilitar la depuración.
ini_set("display_startup_errors", 1); // Muestra errores durante el inicio de PHP
error_reporting(E_ALL); // Muestra todos los errores (incluye E_NOTICE y E_WARNING)
require_once "config/global.php";

// Simulando los valores de querystring (sin usar $_GET para probar)
$querystring = isset($_GET["querystring"]) ? $_GET["querystring"] : ""; // Aquí puedes modificar el valor para probar diferentes casos

// Verifica si la cadena $querystring no termina con un "/" para evitar errores al dividir.
if (!str_ends_with($querystring, "/")) {
    $querystring = $querystring . "/"; // Si falta "/", se le añade.
}

// Debug: Mostrar la cadena de consulta
//echo "Querystring recibido: " . htmlspecialchars($querystring) . "<br>";

// Divide la cadena $querystring en un array utilizando "/" como delimitador.
$peticion = explode("/", $querystring);

// Asigna el primer elemento del array como el controlador. Si no existe, usa una cadena vacía.
$controlador = isset($peticion[1]) ? $peticion[1] : "";

// Asigna el segundo elemento del array como la acción. Si no existe, usa una cadena vacía.
$accion = isset($peticion[2]) ? $peticion[2] : "";

// Asigna el tercer elemento del array como el ID. Si no existe, usa una cadena vacía.
$id = isset($peticion[3]) ? $peticion[3] : "";

// Debug: Mostrar los valores obtenidos
//echo "Controlador: $controlador<br>";
//echo "Acción: $accion<br>";
//echo "ID: $id<br>";

// Switch principal para manejar la lógica según el controlador.
switch ($controlador) {
    case "inicio": {
        //echo "Controlador: producto<br>"; // Debug
        
        // Validación previa para `$accion`
        $accion = $accion ?? "";

        // Sub-switch para manejar las acciones específicas
        switch ($accion) {
            case "": // Acción por defecto
 
            case "catalgo": {
                //echo "Acción: inico<br>"; // Debug
                require_once "";
               // $ctrl = new ();//
                break;
            }
            default: { // Manejo de acciones no válidas
                echo "Error: Acción no válida \"$accion\"<br>"; // Debug
                $ctrl = null; // O manejar un controlador de error
                break;
            }
        }
        break;
    }
    default: {
        //echo "Controlador desconocido \"$controlador\". Usando ruta predeterminada.<br>"; // Debug
        require_once "_controller/CtrlInicio.php"; // Ruta predeterminada
        $ctrl = new CtrlInicio();
        break;
    }
}

// Renderizar la vista si el controlador es válido
if ($ctrl) {
    include "_view/master.html"; // Incluye la vista principal si el controlador es válido.
} else {
    echo "Error 404: Página no encontrada."; // Mensaje de error si el controlador o acción no existen.
}

?>
